#include "stm32f10x.h"
#include "lcd.h"
#include <stdio.h>
#include "stm32f10x_it.h"
#include "stm32f10x_tim.h"
#include "stm32f10x_exti.h"
/*
 
 Project
 
 */

void Delayus(int duration);
void Delaynew(uint16_t i);

GPIO_InitTypeDef GPIO_InitStructure;
TIM_TimeBaseInitTypeDef	TIM_TimeBaseStructure;
TIM_OCInitTypeDef TIM_OCInitStructure;
EXTI_InitTypeDef EXTI_InitStructure;
NVIC_InitTypeDef NVIC_InitStructure;
NVIC_InitTypeDef nvicStructure;

void MCO_CONFIG (void);
int temp = 0;
int i = 0;
char buffer[100];
char buffer2[100];
int ultasound_count = 0;
int distance;
uint32_t time,timeout;

int main ( void )
{
	LCD_INIT ();   
	MCO_CONFIG();
	
	
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	
	while(1){
		GPIOC->BRR=GPIO_Pin_6;
		Delaynew(1);
		GPIOC->BSRR=GPIO_Pin_6;
		Delaynew(5);
		GPIOC->BRR=GPIO_Pin_6;
		
		while((GPIOC->IDR & GPIO_Pin_0)==0x00){
		}
		time=0;
		while((GPIOC->IDR & GPIO_Pin_0)!=0x00){
			time++;
			Delaynew(1);
		}
		timeout=time;
		distance=(float)timeout*0.0171821*2;
		sprintf(buffer,"%d",distance);
		if(distance>=10){
			LCD_DrawString(12, 40, buffer);
			LCD_DrawString(28, 40,"cm");
		}
		else{
			LCD_DrawString(12, 40, buffer);
			LCD_DrawString(20, 40,"cm");
			LCD_Clear(36,40,8,16,WHITE);
		}
		if(distance<30){
			LCD_Clear(36,60,132,16,WHITE);
			sprintf(buffer2,"%d",666*distance+10000);
			LCD_DrawString(36,60,buffer2);
			GPIOC->BSRR=GPIO_Pin_7;
			TIM_OCInitStructure.TIM_Pulse = 666*distance+10000;

			TIM_OC1Init(TIM4, &TIM_OCInitStructure);
			TIM_OC1Init(TIM4,&TIM_OCInitStructure);
			Delayus(1000000);
		}
		else if(distance>=30 && distance<=60){
			LCD_Clear(36,60,132,16,WHITE);
			sprintf(buffer2,"%d",666*distance+10000);
			LCD_DrawString(36,60,buffer2);
			GPIOC->BRR=GPIO_Pin_7;
			TIM_OCInitStructure.TIM_Pulse = 666*distance+10000;

			TIM_OC1Init(TIM4, &TIM_OCInitStructure);
			TIM_OC1Init(TIM4,&TIM_OCInitStructure);
			Delayus(1000000);
		}
		else if(distance>60){
			LCD_Clear(12,40,32,16,WHITE);
			LCD_Clear(36,60,132,16,WHITE);
			LCD_DrawString(36,60,"Switch off");
			TIM_OCInitStructure.TIM_Pulse = 1000-1;
			TIM_OC1Init(TIM4, &TIM_OCInitStructure);
			TIM_OC1Init(TIM4,&TIM_OCInitStructure);
			Delayus(1000000);
		}
		
		

		Delaynew(500);
	}
	
	
}

void MCO_CONFIG (void)
{		
	
RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
RCC_APB1PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
GPIO_Init(GPIOA, &GPIO_InitStructure);


TIM_TimeBaseStructure.TIM_Period = 79; 
TIM_TimeBaseStructure.TIM_Prescaler = 0;
TIM_TimeBaseStructure.TIM_ClockDivision = 0;
TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
TIM_OCInitStructure.TIM_Pulse = 72;
TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
TIM_OC1Init(TIM3, &TIM_OCInitStructure);


TIM_Cmd(TIM3, ENABLE);

RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
GPIO_Init(GPIOB, &GPIO_InitStructure);

TIM_SelectMasterSlaveMode(TIM3, TIM_MasterSlaveMode_Enable);
TIM_SelectOutputTrigger(TIM3, TIM_TRGOSource_Update);

TIM_TimeBaseStructure.TIM_Period = 23999; 
TIM_TimeBaseStructure.TIM_Prescaler = 0;
TIM_TimeBaseStructure.TIM_ClockDivision = 0;
TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
TIM_OCInitStructure.TIM_Pulse = 600; 
TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
TIM_OC1Init(TIM4, &TIM_OCInitStructure);

TIM_SelectSlaveMode(TIM4, TIM_SlaveMode_Gated);
TIM_SelectInputTrigger(TIM4, TIM_TS_ITR2);

RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
TIM_Cmd(TIM4, ENABLE);
}

void Delayus(int duration)
{
		while(duration--) 
		{
			int i=0x02;				
			while(i--)
			__asm("nop");
		}
}
void Delaynew(uint16_t i){
	static uint32_t j=0,ij=0;
	for(ij=0;ij<i;ij++)
		for(j=0;j<1;++j);
}



